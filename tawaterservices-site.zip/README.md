# T&A Services — Static Website

This folder contains a simple static site (`index.html` + `styles.css`).

## Quick preview
Open `index.html` in your browser.

## Deploy to GitHub Pages
1. Create a new repo on GitHub (public).  
2. Upload these files (root of the repo, not in a subfolder).  
3. Repo **Settings → Pages** → Source: **Deploy from a branch** → Branch: `main` / **/** (root) → **Save**.  
4. Your site will appear at `https://<YOUR-USER>.github.io/<repo-name>/`.

## Use your domain (TAWaterServices.com)
Add in **Settings → Pages → Custom domain**: `www.TAWaterServices.com` and enable **Enforce HTTPS**.  
Then, at your registrar (e.g., Namecheap) add DNS:
- CNAME `www` → `<YOUR-USER>.github.io`
- A `@` → `185.199.108.153`
- A `@` → `185.199.109.153`
- A `@` → `185.199.110.153`
- A `@` → `185.199.111.153`
- (Optional AAAA `@` IPv6 values)

## Forms (optional)
Replace the empty `action=""` on forms with a Formspree endpoint to receive emails:
```html
<form action="https://formspree.io/f/yourid" method="POST">…</form>
```

## Logo
The logo is referenced from a hosted URL:
```
https://i.ibb.co/ns81rjZt/T-ALOGONo-Back-Ground.png
```
You can instead download it into `/assets` and update the `src` paths.
